# -*- coding: utf-8 -*-
"""
Created on Tue May 23 08:43:44 2023

@author: juber
"""

import math
import matplotlib.transforms as mtransforms
import matplotlib.collections as mcoll
import numpy as np
import os

def binndata(x,y,C,reduce_C_function,input_dir):
    gridsize=50
    # x=rastercoord[:,:,0].ravel()
    # y=rastercoord[:,:,1].ravel()
    # C=myDepth.ravel()
    #♥reduce_C_function=np.nanmean
    polyname=input_dir+'/hexpoly.npy'
    offname=input_dir+'/hexoff.npy'
    bdistname =input_dir+'/hexbdist.npy'
    i1n =input_dir+'/i1.npy'
    i2n=input_dir+'/i2.npy'
    
    nx = gridsize
    ny = int(nx / math.sqrt(3))
    # Count the number of data in each hexagon
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    mincnt = 0
    # Will be log()'d if necessary, and then rescaled.
    tx = x
    ty = y
    xmin, xmax = (tx.min(), tx.max()) if len(x) else (0, 1)
    ymin, ymax = (ty.min(), ty.max()) if len(y) else (0, 1)
    xmin, xmax = mtransforms.nonsingular(xmin, xmax, expander=0.1)
    ymin, ymax = mtransforms.nonsingular(ymin, ymax, expander=0.1)
    nx1 = nx + 1
    ny1 = ny + 1
    nx2 = nx
    ny2 = ny
    n = nx1 * ny1 + nx2 * ny2
    
    if not os.path.isfile(polyname):
                
                
                # In the x-direction, the hexagons exactly cover the region from
                # xmin to xmax. Need some padding to avoid roundoff errors.
                padding = 1.e-9 * (xmax - xmin)
                xmin -= padding
                xmax += padding
                sx = (xmax - xmin) / nx
                sy = (ymax - ymin) / ny
                # Positions in hexagon index coordinates.
                ix = (tx - xmin) / sx
                iy = (ty - ymin) / sy
                ix1 = np.round(ix).astype(int)
                iy1 = np.round(iy).astype(int)
                ix2 = np.floor(ix).astype(int)
                iy2 = np.floor(iy).astype(int)
                # flat indices, plus one so that out-of-range points go to position 0.
                i1 = np.where((0 <= ix1) & (ix1 < nx1) & (0 <= iy1) & (iy1 < ny1),
                              ix1 * ny1 + iy1 + 1, 0)
                i2 = np.where((0 <= ix2) & (ix2 < nx2) & (0 <= iy2) & (iy2 < ny2),
                              ix2 * ny2 + iy2 + 1, 0)
                np.save(i1n, i1)
                np.save(i2n, i2)
                
                d1 = (ix - ix1) ** 2 + 3.0 * (iy - iy1) ** 2
                d2 = (ix - ix2 - 0.5) ** 2 + 3.0 * (iy - iy2 - 0.5) ** 2
                bdist = (d1 < d2)
                np.save(bdistname, bdist)    # .npy extension is added if not given  
                offsets = np.zeros((n, 2), float)
                offsets[:nx1 * ny1, 0] = np.repeat(np.arange(nx1), ny1)
                offsets[:nx1 * ny1, 1] = np.tile(np.arange(ny1), nx1)
                offsets[nx1 * ny1:, 0] = np.repeat(np.arange(nx2) + 0.5, ny2)
                offsets[nx1 * ny1:, 1] = np.tile(np.arange(ny2), nx2) + 0.5
                offsets[:, 0] *= sx
                offsets[:, 1] *= sy
                offsets[:, 0] += xmin
                offsets[:, 1] += ymin
                # remove accumulation bins with no data     
                polygon = [sx, sy / 3] * np.array(
                    [[.5, -.5], [.5, .5], [0., 1.], [-.5, .5], [-.5, -.5], [0., -1.]])            
                hex_polys=polygon
                offsets2=offsets
                np.save(polyname, hex_polys)    # .npy extension is added if not given  
                np.save(offname, offsets2)    # .npy extension is added if not given 
    else:
                hex_polys = np.load(polyname, allow_pickle=True)
                offsets2 = np.load(offname, allow_pickle=True)
                bdist = np.load(bdistname, allow_pickle=True) 
                i1 = np.load(i1n, allow_pickle=True) 
                i2 = np.load(i2n, allow_pickle=True) 
                # store the C values in a list per hexagon index
    Cs_at_i1 = [[] for _ in range(1 + nx1 * ny1)]
    Cs_at_i2 = [[] for _ in range(1 + nx2 * ny2)]
    
    [Cs_at_i1[i1[i]].append(C[i]) if bdist[i] else Cs_at_i2[i2[i]].append(C[i]) for i in range(len(x))  ]
        
    #for i in range(len(x)):
         #if bdist[i]:
        #     Cs_at_i1[i1[i]].append(C[i])
       #  else:
           #  Cs_at_i2[i2[i]].append(C[i])
             
    if mincnt is None:
        mincnt = 0
    accum = np.array(
        [reduce_C_function(acc) if len(acc) > mincnt else np.nan
         for Cs_at_i in [Cs_at_i1, Cs_at_i2]
         for acc in Cs_at_i[1:]],  # [1:] drops out-of-range points.
        float)
    #offsets2 = offsets2[good_idxs, :]
    #accum = accum[good_idxs]
                
    vv = accum

    return vv,offsets2,hex_polys


