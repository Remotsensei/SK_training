# -*- coding: utf-8 -*-
"""
Created on Tue Feb 28 16:41:40 2023

@author: juber
"""
import numpy as np
def get_raster_origin(coords):
    """Return raster origin
    Parameters
    ----------
    coords : :class:`numpy:numpy.ndarray`
        3 dimensional array (rows, cols, 2) of xy-coordinates
    Returns
    -------
    out : str
        'lower' or 'upper'
    """
    return 'lower' if (coords[1, 1] - coords[0, 0])[1] > 0 else 'upper'

def pixel_coordinates(nx, ny, mode="centers"):
    """Get pixel coordinates from a regular grid with dimension nx by ny.
    Parameters
    ----------
    nx : int
        xsize
    ny : int
        ysize
    mode : string
        `centers` or `centroids` to return the pixel centers coordinates
        otherwise the pixel edges coordinates will be returned
    Returns
    -------
    coordinates : :class:`numpy:numpy.ndarray`
         Array of shape (ny,nx) with pixel coordinates (x,y)
    """
    if mode == "centroids":
        mode = "centers"
    x = np.linspace(0, nx, num=nx + 1)
    y = np.linspace(0, ny, num=ny + 1)
    if mode == "centers":
        x = x + 0.5
        y = y + 0.5
        x = np.delete(x, -1)
        y = np.delete(y, -1)
    X, Y = np.meshgrid(x, y,copy=False)
   # coordinates = np.empty(X.shape + (2,))
    #a = np.zeros((2, 512*512), dtype=np.float32)
    #coordinates[:, :, 0] = X
   # coordinates[:, :, 1] = Y
    coordinates=np.stack((X, Y), axis=-1) 
    return (coordinates)

def getGeoTransform(header):
   
    nx = header['ncols']
    ny = header['nrows']
    xmin, ymin, xmax, ymax = [header['xllcorner']+(0.5*header['cellsize']),
                              header['yllcorner']+(0.5*header['cellsize']),
                              (header['xllcorner']+(0.5*header['cellsize']))+((header['ncols']-1)*header['cellsize']), 
                              header['yllcorner']+(0.5*header['cellsize'])+((header['nrows']-1)*header['cellsize'])]
    xres = (xmax - xmin) / float(nx)
    yres = (ymax - ymin) / float(ny)
    geotransform = (xmin, xres, 0, ymax, 0, -yres)
    return geotransform

def pixel_to_map(geotransform, coordinates):
    """Apply a geographical transformation to return map coordinates from
    pixel coordinates.
    Parameters
    ----------
    geotransform : :class:`numpy:numpy.ndarray`
        geographical transformation vector:
            - geotransform[0] = East/West location of Upper Left corner
            - geotransform[1] = X pixel size
            - geotransform[2] = X pixel rotation
            - geotransform[3] = North/South location of Upper Left corner
            - geotransform[4] = Y pixel rotation
            - geotransform[5] = Y pixel size
    coordinates : :class:`numpy:numpy.ndarray`
        2d array of pixel coordinates
    Returns
    -------
    coordinates_map : :class:`numpy:numpy.ndarray`
        3d array with map coordinates x,y
    """
    coordinates_map = coordinates
    coordinates_map[..., 0] = (geotransform[0] +
                               geotransform[1] * coordinates[..., 0] +
                               geotransform[2] * coordinates[..., 1])
    coordinates_map[..., 1] = (geotransform[3] +
                               geotransform[4] * coordinates[..., 0] +
                               geotransform[5] * coordinates[..., 1])
    
    return (coordinates_map)


def world_to_pixel(geo_matrix, x, y):
    """
    Uses a gdal geomatrix (gdal.GetGeoTransform()) to calculate
    the pixel location of a geospatial coordinate
    """
    ul_x= geo_matrix[0]
    ul_y = geo_matrix[3]
    x_dist = geo_matrix[1]
    y_dist = geo_matrix[5]
    try:
        pixel = ((x - ul_x) / x_dist).astype(int)
        line = -((ul_y - y) / y_dist).astype(int)
    except:
        pixel = int((x - ul_x) / x_dist)
        line = -int((ul_y - y) / y_dist)
        
    return pixel, line