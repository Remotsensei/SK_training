import glob,os,re,shutil,h5py,subprocess,re,datetime,requests,json
import warnings
import numpy as np
import pandas as pd
import gc
from time import sleep

import matplotlib.pyplot as plt
from mplleaflet import mplexporter
from mplleaflet import leaflet_renderer
from mplleaflet import _display
import utm
import rasterutil as rutil

import scipy.interpolate as spint
import scipy.spatial.qhull as qhull
import itertools
from skimage.draw import polygon2mask as pg2mk
from matplotlib.patches import Polygon
####Functions
#replace specific line in file
def replace_line(file_name, line_num, text):
    lines = open(file_name, 'r').readlines()
    lines[line_num] = text
    out = open(file_name, 'w')
    out.writelines(lines)
    out.close()
    
#close all open hdf
def closeAllHDF():
    for obj in gc.get_objects():   # Browse through ALL objects
        if isinstance(obj, h5py.File):   # Just HDF5 files
            try:
                obj.close()
            except:
                pass # Was already closed
                
# get the boundaries keys from the hdf file
def getB(hdf_filename,type):
    hf = h5py.File(hdf_filename,'r') 
    Ky=hf['Event Conditions']['Unsteady']['Boundary Conditions'][type].keys()
    return Ky
    
    
def createTempFile(hdf_filename):
    closeAllHDF()
    #remove existing temp file
    if os.path.exists(os.path.splitext(hdf_filename)[0]+'.tmp.hdf'):
            os.remove(os.path.splitext(hdf_filename)[0]+'.tmp.hdf')            
    #read the input 'original' hdf, and remove the results
    if not os.path.exists(os.path.splitext(hdf_filename)[0]+'.tmp.hdf'):
            fsource=h5py.File(hdf_filename,'r')
            fdest=h5py.File(os.path.splitext(hdf_filename)[0]+'.tmp.hdf','w')
            for fattr in fsource.attrs.keys():
                fdest.attrs[fattr]=fsource.attrs.get(fattr)
            for fg in fsource.keys():
                if fg !='Results' :
                    fsource.copy(fg,fdest)        
            fdest.close()
            fsource.close()
    fdest=os.path.splitext(hdf_filename)[0]+'.tmp.hdf'
    return fdest
            
#function to read the CSV files from CREST.
def readCrestBASEFLOW(filename):
    datetimeFormat='%Y/%m/%d:%H'
    upstream = pd.read_csv(filename)
    upstream['Date'] = pd.to_datetime(upstream['Date'], format=datetimeFormat) 
    return upstream

##write flows into HDF from hecras
#fdest = destination file
#fsource = source hdf to duplicate
#d1= touple of flows and time interval 
#dt time interval to get start and end
#actual key= key to read in the HDF
#item subkey indicating which boundary condition to write
def alterateKey(fdest,fsource,d1,dt,actualKey,item):
        time2write1=np.array(datetime.datetime.strptime(dt[0],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H%M')).astype('S')
        time2write2=np.array(datetime.datetime.strptime(dt[-1],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H%M')).astype('S')
        time2write3=np.array(datetime.datetime.strptime(dt[0],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H:%M:%S')).astype('S')
        time2write4=np.array(datetime.datetime.strptime(dt[-1],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H:%M:%S')).astype('S')
        t4=np.array(datetime.datetime.strptime(dt[0],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H:%M:%S') +' to ' + datetime.datetime.strptime(dt[-1],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H:%M:%S')).astype('S')
        fs=h5py.File(fsource,'r')
        ds= h5py.File(fdest,'r+')
        try:
                  del ds['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item] # delete old, differently sized dataset
        except:
                  None
        try:
                  ds.create_dataset('Event Conditions/Unsteady/Boundary Conditions/'+actualKey+'/'+item, data=d1,shape=d1.shape)
        except:
                  ds.create_dataset('Event Conditions/Unsteady/Boundary Conditions/'+actualKey+'/'+item, data=d1)
        for fattr in fs['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item].attrs.keys():
            if fattr=='Start Date':
                ds['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item].attrs[fattr]=time2write1
            elif fattr=='End Date':
                ds['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item].attrs[fattr]=time2write2
            else:
                try:
                    ds['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item].attrs[fattr]=fs['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item].attrs.get(fattr)
                except:
                    ds['Event Conditions']['Unsteady']['Boundary Conditions'][actualKey][item].attrs[fattr]=''
        for fattr in fs['Plan Data']['Plan Information'].attrs.keys():
            if fattr=='Simulation Start Time':
                ds['Plan Data']['Plan Information'].attrs[fattr]=time2write3
            elif fattr=='Simulation End Time':
                ds['Plan Data']['Plan Information'].attrs[fattr]=time2write4
            elif fattr=='Time Window':
                ds['Plan Data']['Plan Information'].attrs[fattr]=t4           
        fs.close()
        ds.close()


##fix B01 file
def alterateBfile(folder,project_name,plan_index_str,dt):
        planFile=folder+'/'+'{}.b{}'.format(project_name, plan_index_str)
        time2write1=datetime.datetime.strptime(dt[0],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H%M')
        time2write2=datetime.datetime.strptime(dt[-1],'%Y/%m/%d:%H').replace(tzinfo=datetime.timezone.utc).strftime('%d%b%Y %H%M')
        replace_line(planFile, 46, '  Start Date/Time       = '+time2write1+'\n')
        replace_line(planFile, 47, '  End Date/Time         = '+time2write2+'\n')
        

##workaround to convert dos to unix
def dos2unixlocal(job_file,input_dir):
    pipe = subprocess.Popen("tr -d '\r' < %s >  plan.x" %job_file,shell=True,cwd=input_dir)
    pipe.wait()
    while True:
        doesItExist=os.path.exists('{}/{}'.format(input_dir,'plan.x'))
        if doesItExist:
            break
        else:
            sleep(30)
    pipe = subprocess.Popen("mv plan.x %s" %job_file,shell=True,cwd=input_dir)
    pipe.wait()
    while True:
        doesItExist=os.path.exists(job_file)
        if doesItExist:
            break
        else:
            sleep(30)

##function to launch hec rasUnsteady64

#function to run hecras in linux
def runHEC(geom_index_str,plan_index_str,folder,hecPath,project_name,account,partition,ntasks,nnodes):
    if os.path.exists('{}/{}.p{}.hdf_done'.format(folder,project_name, plan_index_str)):
            os.remove('{}/{}.p{}.hdf_done'.format(folder,project_name, plan_index_str))
    fileforsh = ''.join([c for c in project_name if c not in "aeiouAEIOU"])
    job_file=folder+'/'+fileforsh+'.sh'
    if os.path.exists(job_file):
            os.remove(job_file)
    print('launching job'+fileforsh)
    str1=hecPath+'{}.c{} b{}\n'.format(project_name,geom_index_str,geom_index_str)
    str2='mv '+'{}/{}.p{}.tmp.hdf '.format(folder,project_name, plan_index_str)+'{}/{}.p{}.hdf_done\n'.format(folder,project_name, plan_index_str)
    str3='module load gcc/5.4.0\n'
    str4='RAS_BIN_PATH='+os.path.dirname(hecPath)+'\n'
    str5='export LD_LIBRARY_PATH=$RAS_BIN_PATH:$LD_LIBRARY_PATH\n'
    with open(job_file,'w') as fh:
            fh.writelines("#!/bin/bash -l\n")
            if account=='':
                pass
            else:
                fh.writelines("#SBATCH --account=%s\n" % account)
            fh.writelines("#SBATCH --partition=%s\n" % partition)
            fh.writelines("#SBATCH --nodes=%s\n" % nnodes)
            #fh.writelines("#SBATCH --mem=64G\n")
            #fh.writelines("#SBATCH --ntasks=%s\n" % ntasks)
            fh.writelines("#SBATCH --output=%s.HECout\n" % project_name)
            fh.writelines("#SBATCH --error=%s.HECerr\n" % project_name)
            fh.writelines(str4)
            fh.writelines(str5)
            #fh.writelines(str3)
            fh.writelines(str1)
            fh.writelines(str2)
    ##convert dos to unix
    pipe = subprocess.Popen("tr -d '\r' < %s >  job.sh" %job_file,shell=True,cwd=folder)
    pipe.wait()
    pipe = subprocess.Popen("mv job.sh %s" %job_file,shell=True,cwd=folder)
    pipe.wait()       
    
    # Call RasMapper to generate tif
    pipe = subprocess.Popen("sbatch %s" %job_file,shell=True,cwd=folder)
    pipe.wait()
    while True:
    	doesItExist=os.path.exists('{}/{}.p{}.hdf_done'.format(folder,project_name, plan_index_str))
    	if doesItExist:
    		break
    	else:
    		sleep(30)
    return doesItExist
    
    
##function to get the DEM from opentopography API
def getEE(hdf_filename,input_dir,DEMfile):
        fname=input_dir+'/'+DEMfile
        HRAS=h5py.File(hdf_filename,'r') # Read HEC-RAS 2D HDF output 
        TwoDAreaNames = HRAS['Geometry']['2D Flow Areas']['Attributes']['Name']
        Name=TwoDAreaNames[0]
        exts = HRAS['Geometry']['2D Flow Areas'][Name].attrs['Extents']
        # extract the perimeter data of the 2D interior area
        perimeter = HRAS['Geometry']['2D Flow Areas'][Name]['Perimeter']
        perimeter = np.array(perimeter)
        try:
            projction=HRAS.attrs['Projection']
            utmF=projction.astype(str).split('UTM_Zone_')[1].split('",')[0]
        except:
            projction=open(input_dir+'/projection.projection', 'r').readlines()[0]
            utmF=projction.split('UTM_Zone_')[1].split('",')[0]
        HRAS.close()
        points_list=[(exts[0],exts[2]),(exts[1],exts[3])]
        fuseNumber=int(re.findall(r'\d+',utmF)[0])
        fuseLetter=[s for s in utmF if not s.isdigit()][0]
        Lat1,Lon1=utm.to_latlon(exts[0], exts[2], fuseNumber, fuseLetter,strict=0)
        Lat2,Lon2=utm.to_latlon(exts[1], exts[3], fuseNumber, fuseLetter,strict=0)
        if not os.path.isfile(fname):   
            url = 'https://portal.opentopography.org/API/globaldem?';
            demtype='COP30'
            apikey='3bcf47df576e2b194d675751e70f98a5'
        
            parameters = {'west':min(Lon1,Lon2),
                           'east':max(Lon1,Lon2),
                           'north':max(Lat1,Lat2), #msl
                           'south':min(Lat1,Lat2),
                           'outputFormat':'AAIGrid',
                           'demtype':demtype,
                           'API_Key': apikey                
                                  }   
            query_url = requests.Request(
                'GET', url, params=parameters).prepare().url
            response = requests.get(query_url,verify=False)  # Get data from URL 
            
            open(fname, 'wb').write(response.content)
        head = pd.read_csv(fname,nrows=6,delim_whitespace=True,header=None, on_bad_lines='skip')    
        header_rows = 0    
        header={}
        for line in head.iterrows():
                 header_rows=header_rows+1
                 header[line[1][0]] = float(line[1][1])
        if header['cellsize']>1 and header['cellsize']<5:
           correctfuse=utm.from_latlon(Lat2,Lon2)[2]
           newH=utm.to_latlon(header['xllcorner'],header['yllcorner'],correctfuse,'N',strict=0)
           newH=utm.from_latlon(newH[0],newH[1],fuseNumber,'N')
           header['xllcorner']=newH[0]
           header['yllcorner']=newH[1]
        chunks = pd.read_csv(fname,skiprows=header_rows,header=None,delim_whitespace=True, chunksize=1000, dtype=np.float64)
        data_array = pd.concat(chunks).values
        while (data_array.shape[1]!=header['ncols'] or data_array.shape[0]!=header['nrows']):
             url = 'https://portal.opentopography.org/API/globaldem?';
             demtype='COP30'
             apikey='3bcf47df576e2b194d675751e70f98a5'
             parameters = {'west':min(Lon1,Lon2),
                            'east':max(Lon1,Lon2),
                            'north':max(Lat1,Lat2), #msl
                            'south':min(Lat1,Lat2),
                            'outputFormat':'AAIGrid',
                            'demtype':demtype,
                            'API_Key': apikey                
                                   }   
             query_url = requests.Request(
                 'GET', url, params=parameters).prepare().url
             response = requests.get(query_url,verify=False)  # Get data from URL 
             open(fname, 'wb').write(response.content)
             chunks = pd.read_csv(fname,skiprows=header_rows,header=None,delim_whitespace=True, chunksize=1000, dtype=np.float64)
             data_array = pd.concat(chunks).values
        #get transformation matrix in latlon
        GT=rutil.getGeoTransform(header)
        pixelcoord=rutil.pixel_coordinates(int(header['ncols']),int(header['nrows']))
        rastercoord=rutil.pixel_to_map(GT,pixelcoord)
        return data_array,rastercoord,pixelcoord,header,fuseNumber,fuseLetter


##function to get the beginning and end of the simulation from the HDF file
def getsimtime(hdf_filename):
        HRAS=h5py.File(hdf_filename,'r') # Read HEC-RAS 2D HDF output 
        TwoDAreaNames = HRAS['Geometry']['2D Flow Areas']['Attributes']['Name']
        Name=TwoDAreaNames[0]
        exts = HRAS['Geometry']['2D Flow Areas'][Name].attrs['Extents']
        # extract the perimeter data of the 2D interior area
        perimeter = HRAS['Geometry']['2D Flow Areas'][Name]['Perimeter']
        perimeter = np.array(perimeter)
        # extract the data of time date stamp
        td = HRAS['/Results/Unsteady/Output/Output Blocks/Base Output/Unsteady Time Series/Time Date Stamp']
        # trsnform data type from bytestring to string
        td = np.char.decode(td)
        HRAS.close()
        return td
  
##function to retrieve the hourly results from the HDF file

def getResults_hourInterval(hdf_filename,input_dir,DEMfile,typeOfResult,elevation,rastercoord,pixelcoord,beg,ending):
        fname=input_dir+'/'+DEMfile
        # Definition of the fast  interpolation process. May be the Tirangulation process can be removed !!
        def interp_weights(xy,uvw):
            tri = qhull.Delaunay(xy)
            simplex = tri.find_simplex(uvw)
            vertices = np.take(tri.simplices, simplex, axis=0)
            temp = np.take(tri.transform, simplex, axis=0)
            delta = uvw - temp[:, 2]
            bary = np.einsum('njk,nk->nj', temp[:, :2, :], delta)
            return vertices, np.hstack((bary, 1 - bary.sum(axis=1, keepdims=True)))
            
            
        def interpolate(values, vtx, wts, fill_value=np.nan):
            ret = np.einsum('nj,nj->n', np.take(values, vtx), wts)
            ret[np.any(wts < 0, axis=1)] = fill_value
            return ret 
            
            
        HRAS=h5py.File(hdf_filename,'r') # Read HEC-RAS 2D HDF output 
        TwoDAreaNames = HRAS['Geometry']['2D Flow Areas']['Attributes']['Name']
        Name=TwoDAreaNames[0]
        exts = HRAS['Geometry']['2D Flow Areas'][Name].attrs['Extents']
        # extract the perimeter data of the 2D interior area
        perimeter = HRAS['Geometry']['2D Flow Areas'][Name]['Perimeter']
        perimeter = np.array(perimeter)
        # extract the data of time date stamp
        td = HRAS['/Results/Unsteady/Output/Output Blocks/Base Output/Unsteady Time Series/Time Date Stamp']
        # trsnform data type from bytestring to string
        td = np.char.decode(td)
        td=td[beg:ending]
        if typeOfResult=='Depth':
            c =HRAS['Geometry']['2D Flow Areas'][Name]['Cells Center Coordinate']
            c = np.array(c)
            # store x-coordinate and y-coordinate data in saparate lists
            x, y = c.T
            c =HRAS['Geometry']['2D Flow Areas'][Name]['Cells Minimum Elevation']
            #c = np.array(c)
            # extract the data of water surface elevation
            #wse = f['/Results/Unsteady/Output/Output Blocks/Base Output/Unsteady Time Series/2D Flow Areas/Perimeter 1/Water Surface']
            #wse = np.array(wse)
            # extract the data of water depth
            wde = HRAS['Results']['Unsteady']['Output']['Output Blocks']['Base Output']['Unsteady Time Series']['2D Flow Areas'][Name]['Water Surface']#'Depth
            wde=wde[beg:ending,]
            pre_allocated = np.empty(shape=wde.shape)
            np.subtract(wde, c, out=pre_allocated)
            #wde = np.array(wde)-c
            wde=pre_allocated
            dp=np.amax(wde, axis=0).T
            coords=np.vstack([x,y]).T
        else:
            wde = HRAS['Results']['Unsteady']['Output']['Output Blocks']['Base Output']['Unsteady Time Series']['2D Flow Areas'][Name]['Face Velocity']
            wde = np.array(wde)
            c =HRAS['Geometry']['2D Flow Areas'][Name]['Cells Center Coordinate']
            c = np.array(c)
            x_, y_ = c.T
            #GET FACEpoint coordinates
            fc =HRAS['Geometry']['2D Flow Areas'][Name]['Faces Cell Indexes']
            fc = np.array(fc)
            x2, y2 = fc.T
            x=x_[x2]
            y=y_[y2]
            wde=wde[beg:ending,]
            dp=np.amax(wde, axis=0).T
            coords=np.vstack([x,y]).T
            #↑get cell area to compensate afterwards
            ca =HRAS['Geometry']['2D Flow Areas'][Name]['Cells Surface Area']
            ca = np.array(ca)
            ldname1=input_dir+'linearInt1.npy'
            ldname2=input_dir+'linearInt2.npy'
            if not os.path.isfile(ldname1):
                vtx, wts = interp_weights(np.vstack([x_,y_]).T, np.vstack([x, y]).T) ##sono qui
                np.save(ldname1, vtx)    # .npy extension is added if not given  
                np.save(ldname2, wts)    # .npy extension is added if not given 
            else:
                vtx = np.load(ldname1, allow_pickle=True)
                wts = np.load(ldname2, allow_pickle=True)
            ca=interpolate(ca,vtx, wts,0)
            #interp = LinearNDInterpolator(list(zip(x_, y_)), ca)
            #ca= interp(x, y)
            dp=dp*ca/100
            wde=wde*ca/100
        try:
            projction=HRAS.attrs['Projection']
            utmF=projction.astype(str).split('UTM_Zone_')[1].split('",')[0]
        except:
            projction=open(input_dir+'/projection.projection', 'r').readlines()[0]
            utmF=projction.split('UTM_Zone_')[1].split('",')[0]
        HRAS.close()
        fuseNumber=int(re.findall(r'\d+',utmF)[0])
        fuseLetter=[s for s in utmF if not s.isdigit()][0]
        Lat1,Lon1=utm.to_latlon(exts[0], exts[2], fuseNumber, fuseLetter,strict=0)
        Lat2,Lon2=utm.to_latlon(exts[1], exts[3], fuseNumber, fuseLetter,strict=0)
        head = pd.read_csv(fname,nrows=6,sep='\t',header=None)    
        header_rows = 0    
        header={}
        for line in head.iterrows():
                 line1 = line[1][0].split(" ", 1)
                 try:
                     header_rows=header_rows+1
                     header[line1[0]] = float(line1[1])
                 except:
                     line1
        if header['cellsize']>1 and header['cellsize']<5:
           correctfuse=utm.from_latlon(Lat2,Lon2)[2]
           newH=utm.to_latlon(header['xllcorner'],header['yllcorner'],correctfuse,'N',strict=0)
           newH=utm.from_latlon(newH[0],newH[1],fuseNumber,'N')
           header['xllcorner']=newH[0]
           header['yllcorner']=newH[1]
        trgname=input_dir+'/trg.npy'
        mskname=input_dir+'/msk.npy'
        if not os.path.isfile(trgname):
            GT=rutil.getGeoTransform(header)
            if header['cellsize']<1:
                per=utm.to_latlon(perimeter[:,0],perimeter[:,1],fuseNumber, fuseLetter,strict=False)
                col,row=rutil.world_to_pixel(GT, per[1], per[0])
            else:
                col,row=rutil.world_to_pixel(GT, perimeter[:,0], perimeter[:,1])

            #create mask of 2d domain
            image_shape = (int(header['nrows']), int(header['ncols']))
            mask = pg2mk(image_shape, np.vstack([row,col]).T)
            [rr,cc]=np.where(mask)
            #transform everything to UTM
            if header['cellsize']<1:
                rastercoord_t=utm.from_latlon(rastercoord[:,:,1],rastercoord[:,:,0], fuseNumber, fuseLetter)
                rastercoord_t=np.stack((rastercoord_t[0], rastercoord_t[1]), axis=-1) 
                csize=30
            else:
                rastercoord_t=rastercoord
                csize=header['cellsize']

            #transform the domain into actual coordinates
            newCoord=rastercoord_t[rr,cc,:]
            trg=np.vstack([newCoord[:,0],newCoord[:,1]]).T 
            np.save(trgname, trg)    # .npy extension is added if not given 
            np.save(mskname, mask)    # .npy extension is added if not given 
        else:
            trg = np.load(trgname, allow_pickle=True)   
            mask = np.load(mskname, allow_pickle=True)
        if typeOfResult=='Depth':
            sInname1=input_dir+'/vtx.npy'
            sInname2=input_dir+'/wts.npy'
        else:
            sInname1=input_dir+'/vtx_V.npy'
            sInname2=input_dir+'/wts_V.npy'
        if not os.path.isfile(sInname1):
            vtx, wts = interp_weights(coords, trg)
            np.save(sInname1, vtx)    # .npy extension is added if not given  
            np.save(sInname2, wts)    # .npy extension is added if not given 
        else:
            vtx = np.load(sInname1, allow_pickle=True)
            wts = np.load(sInname2, allow_pickle=True)
        data=interpolate(dp,vtx, wts,0)
        myDepth2=np.zeros(mask.shape)
        myDepth2[mask==1]=data
       #time analysis
        if typeOfResult=='Depth':
            myArr=np.array([0,.2,1,2])
            #mythresholds=[myArr[myArr <y_axis].max() for y_axis in dp if y_axis>0]
            f = lambda x:  myArr[myArr <x].max() 
            row_arange_t = np.vectorize(f, signature="()->()")
            mythresholds=row_arange_t(dp[dp>0])
            myth=np.zeros(dp.shape)
            myth[dp>0]=mythresholds
            condition=(wde>myth)*1.0
            condition[wde<=.2]=0
            def contiguous_regions(condition):
                """Finds contiguous True regions of the boolean array "condition". Returns
                a 2D array where the first column is the start index of the region and the
                second column is the end index."""
                # Find the indicies of changes in "condition"
                d = np.diff(condition)
                idx, = d.nonzero() 
                # We need to start things after the change in "condition". Therefore, 
                # we'll shift the index by 1 to the right.
                idx += 1
                if condition[0]:
                    # If the start of condition is True prepend a 0
                    idx = np.r_[0, idx]
                if condition[-1]:
                    # If the end of condition is True, append the length of the array
                    idx = np.r_[idx, condition.size] # Edit
               # Reshape the result into two columns
                idx.shape = (-1,2)
                return idx 
                
                
                
            def contiguous_regions2(condition):
                idx = []
                i = 0
                while i < len(condition):
                    x1 = i + condition[i:].argmax()
                    try:
                        x2 = x1 + condition[x1:].argmin()
                    except:
                        x2 = x1 + 1
                    if x1 == x2:
                        if condition[x1] == True:
                            x2 = len(condition)
                        else:
                            break
                    idx.append( [x1,x2] )
                    i = x2
                return idx
                
                
                
            def split_above_threshold(signal,wde,z,dp):
                if (sum(signal)>0 and dp[z]>=0.2):#if depth is above 0.2 and i have some events
                    for start, stop in contiguous_regions2(signal):
                        pp=wde[start:stop,z]
                        mxdp=dp[z]
                        if (pp==mxdp).any():
                            pktime=np.where(pp==mxdp)[0]
                            pktime=pktime[0]+start
                            break    
                    return [start,stop,pktime]
                else:
                    return [np.nan,np.nan,np.nan]
                    
                    
                    
            f2 = lambda y,z:  split_above_threshold(y,wde,z,dp)
            t=np.array([f2(y,z) for z,y in enumerate(condition.transpose())])
              #t= [split_above_threshold(y,wde,z,dp) for z,y in enumerate(condition.transpose())]
            #append last hour
            td2=np.append(td,td[-1])
            timestampformap=np.array([datetime.datetime.strptime(xx, "%d%b%Y %H:%M:%S").timestamp() * 1000 for xx in td2])
            start=np.zeros(dp.shape)*np.nan
            ok=t[np.isfinite(t[:,0]),0].astype(int)
            start[np.isfinite(t[:,0])]=timestampformap[ok]
            end=np.zeros(dp.shape)*np.nan
            ok=t[np.isfinite(t[:,1]),1].astype(int)
            end[np.isfinite(t[:,1])]=timestampformap[ok]
            peak=np.zeros(dp.shape)*np.nan
            ok=t[np.isfinite(t[:,2]),2].astype(int)
            peak[np.isfinite(t[:,2])]=timestampformap[ok]
            timestart=interpolate(start,vtx, wts,0)
            timesEnd=interpolate(end,vtx, wts,0)
            timesPeak=interpolate(peak,vtx, wts,0)
            a2=np.zeros([mask.shape[0],mask.shape[1],3])
            a2[mask==1,0]=timestart
            a2[mask==1,1]=timesPeak
            a2[mask==1,2]=timesEnd
        else:
            a2=np.nan
        #timemap3=griddata(coords, maxDtimes[2,:].T, trg, method='nearest')
        myDepth=np.zeros(mask.shape)
        myDepth[mask==1]=data
        return myDepth,td,a2
    
#helper functions for plotting the warnings
def gettime2(z,dt,i,timeserie):
                    if z['properties']['time1']!='':
                        st = datetime.datetime.strptime(z['properties']['s1'],"%d%b%Y %H:%M:%S")
                        en = datetime.datetime.strptime(z['properties']['e1'],"%d%b%Y %H:%M:%S")   
                        colortimeserie=[z['properties']['fillColor']  if (datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")>=st and datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")<=en) else '' for timex in dt  ]
                        peaktimeserie=[z['properties']['time1']  if (datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")>=st and datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")<=en) else '' for timex in dt  ]
                        vetimeserie=['' for timex in dt  ]
                        s1timeserie=[z['properties']['s1']  if (datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")>=st and datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")<=en) else '' for timex in dt  ]
                        e1timeserie=[z['properties']['e1']  if (datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")>=st and datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")<=en) else '' for timex in dt  ]
                        depthtimeserie=[z['properties']['depth1']  if (datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")>=st and datetime.datetime.strptime(timex,"%d%b%Y %H:%M:%S")<=en) else '' for timex in dt  ]
                        #empty=['' for timex in dt  ]
                        z['properties'].update({'timeSerie':colortimeserie})
                        z['properties'].update({'timeValues':timeserie})
                        z['properties'].update({'pkValues':peaktimeserie})
                        z['properties'].update({'stValues':s1timeserie})
                        z['properties'].update({'veValues':vetimeserie})
                        z['properties'].update({'eValues':e1timeserie})
                        z['properties'].update({'depValues':depthtimeserie})
                    else:
                        colortimesrie=['#FFFFFF' for timex in dt  ]
                        empty=['' for timex in dt  ]
                        z['properties'].update({'timeSerie':colortimesrie})
                        z['properties'].update({'timeValues':timeserie})
                        z['properties'].update({'pkValues':empty})
                        z['properties'].update({'stValues':empty})
                        z['properties'].update({'veValues':empty})
                        z['properties'].update({'eValues':empty})
                        z['properties'].update({'depValues':empty})
                    z['properties'].update({'id':i})
                    return z['properties']

def gettime_empty(z,dt,i,timeserie):
                        colortimesrie=['#FFFFFF' for timex in dt  ]
                        empty=['' for timex in dt  ]
                        z['properties'].update({'timeSerie':colortimesrie})
                        z['properties'].update({'timeValues':timeserie})
                        z['properties'].update({'pkValues':empty})
                        z['properties'].update({'stValues':empty})
                        z['properties'].update({'veValues':empty})
                        z['properties'].update({'eValues':empty})
                        z['properties'].update({'depValues':empty})
                        z['properties'].update({'id':i})
                        return z['properties']


##functions to create the htmls
def HTMLforDepth(myDepth,elevation,dt,working_dir,project_name,header,rastercoord,fuseNumber,fuseLetter,op):
    plottitle=str(dt[0])+'_to_'+str(dt[-1])
    title=re.sub(' ','',plottitle)
    title=re.sub(':','',title)
    #fnm=working_dir+project_name+'MaxDepth' +'_'+title+'.html'
    fnm=working_dir+project_name+'MaxDepth' +'_'+title+'.html'
    fig, ax = plt.subplots(figsize = (10,7))
    #retrieve polygons from collection
    #levels= [0.01,.35,.67,1,1.35,1.67,2]
    levels= [0.01,.1,.5,1,2,3,4]
    myDepth[myDepth<=0]=np.nan
    myDepth[elevation<=0]=np.nan
    cs=plt.contourf(rastercoord[:,:,0],rastercoord[:,:,1],myDepth,levels)#,
    plt.close(fig)
    colors2=['#c0d4f5','#7b9ff9','#3b4cc0','#f2cbb7','#ee8468','#b40426']
    fig, ax1 = plt.subplots(figsize = (10,7))
    for i, collection in enumerate(cs.collections): #each collection correspond to one color
        color=colors2[i]
        if i>-1:
            for path in collection.get_paths():
                
                if path.to_polygons():
                    for npoly, polypoints in enumerate(path.to_polygons()):
                       if header['cellsize']>1:
                               rastercoordt=utm.to_latlon(polypoints[:, 0],polypoints[:, 1], fuseNumber, fuseLetter,strict=0)
                               poly_lons = rastercoordt[ 1]
                               poly_lats = rastercoordt[ 0]
                       else:
                           poly_lons = polypoints[:, 0]
                           poly_lats = polypoints[:, 1]
                        # be careful with the following---check to make sure
                        # your coordinate system expects lat first, lon second
                       poly_init = Polygon([coords for coords in \
                                             zip(poly_lons,poly_lats)],
                                                alpha=.7,
                                                edgecolor="none",
                                               facecolor=color)
                       ax1.add_patch(poly_init)
    from mplleaflet import mplexporter
    from mplleaflet import leaflet_renderer
    import json
    renderer = leaflet_renderer.LeafletRenderer(crs=None, epsg=None)
    exporter = mplexporter.Exporter(renderer)
    exporter.run(fig)
    gjdata = renderer.geojson()
    [z['properties'].update({'time':(datetime.datetime.strptime(dt[0],"%d%b%Y %H:%M:%S")).strftime("%Y-%m-%dT%H:%M:%S")})  for i,z in enumerate(gjdata['features']) ]
    from mplleaflet import _display
    if op:
        _display.fig_to_html2(gjdata,fig=fig, template='baseDPT2.html', path=fnm)
    #mplleaflet.show(fig=fig, template='baseDPT2.html', path=fnm,tiles='cartodb_positron')
    plt.close(fig)
    return gjdata

#helper to write html
def dohtm(gjData1,gjData2,title,templats,fnm,timeserie,k):
    fig, ax = plt.subplots(figsize = (10,7))
    _display.fig_to_html5(gjData1,gjData2,title,k,fig=fig, template=templats, path=fnm)
    plt.close(fig)
    
def HTMLforWarningEventsFast(myDepth,myVelocity,elevation,dt,working_dir,project_name,header,rastercoord,fuseNumber,fuseLetter,a2,input_dir,op):
    plottitle=str(dt[0])+'_to_'+str(dt[-1])
    title=re.sub(' ','',plottitle)
    title=re.sub(':','',title)
    fnm=working_dir+project_name+'_warning_'+title+'.html'

    

    def find_nearest(array, value):
            array = np.asarray(array)
            idx = (np.abs(array - value)).argmin()
            return idx    
     #retrieve polygons from collection
    #levels= [0.01,.35,.67,1,1.35,1.67,2]
    colors2=['#FFFFFF','#7b9ff9','#ffa500','#b40426']
    vals2=[0,.2,1,2]
    
    
    myDepth[myDepth<=0]=np.nan
    myDepth[elevation<=0]=np.nan
    
    myVelocity[myDepth<=0]=np.nan
    myVelocity[elevation<=0]=np.nan

    a2[myDepth<=0,:]=np.nan
    a2[elevation<=0,:]=np.nan
    #a2[a2<=0,]=np.nan
    def sum_i(z):
        a=np.asarray(z)
        if np.nansum(a>0)>0:
            x=np.nanmean(a[a>0])
        else:
            x=np.nanmean(a)
        return x
    import statistics
    def sum_i2(z):
        a=np.asarray(z) 
        
        if np.nansum(a>0)>0:
            g=a[a>0]
            x=statistics.median_low(g)
        else:
            g=a
            x=statistics.median_low(g)
        return x
    #depth map
    import binner as bp
    # x=rastercoord[:,:,0].ravel()
    # y=rastercoord[:,:,1].ravel()
    # C=myDepth.ravel()
    #reduce_C_function=np.nanmean
    vv,offsets2,hex_polys=bp.binndata(rastercoord[:,:,0].ravel(),rastercoord[:,:,1].ravel(),myDepth.ravel(),np.nanmean,input_dir)
    good_idxs = ~np.isnan(vv)
    
    #time maps
    t1,oo,oo=bp.binndata(rastercoord[:,:,0].ravel(),rastercoord[:,:,1].ravel(),a2[:,:,0].ravel(),sum_i2,input_dir) #start
    t2,oo,oo=bp.binndata(rastercoord[:,:,0].ravel(),rastercoord[:,:,1].ravel(),a2[:,:,1].ravel(),sum_i2,input_dir) #peak
    t3,oo,oo=bp.binndata(rastercoord[:,:,0].ravel(),rastercoord[:,:,1].ravel(),a2[:,:,2].ravel(),sum_i2,input_dir) #end
    
    #velocity
    vv3,oo,oo=bp.binndata(rastercoord[:,:,0].ravel(),rastercoord[:,:,1].ravel(),myVelocity.ravel(),sum_i,input_dir) #velocity
    
    ##keep only where i have valid depths
    vv=vv[good_idxs]
    t1=t1[good_idxs]
    t2=t2[good_idxs]
    t3=t3[good_idxs]
    vv3=vv3[good_idxs]
    offsets2=offsets2[good_idxs, :]
    
    #convert to timestamp
    def rounddowntoClosest(my_ms,dt,pk,f):
        arrr=[datetime.datetime.strptime(di,"%d%b%Y %H:%M:%S") for di in dt]
        pk=find_nearest(arrr, datetime.datetime.fromtimestamp(pk / 1000))
        x=find_nearest(arrr, datetime.datetime.fromtimestamp(my_ms / 1000))
        if (dt[pk]==dt[x] and (not f is None)):
            if f==1:
                out=(datetime.datetime.strptime(dt[x],"%d%b%Y %H:%M:%S") - datetime.timedelta(hours=0, minutes=30)).strftime("%d%b%Y %H:%M:%S")
            else:
                out=(datetime.datetime.strptime(dt[x],"%d%b%Y %H:%M:%S") + datetime.timedelta(hours=0, minutes=30)).strftime("%d%b%Y %H:%M:%S")
        else:
            out=dt[x]
        return out
    

    #rounded = now - (now - datetime.min) % timedelta(minutes=30)
    t1a = [rounddowntoClosest(my_ms,dt,t2[i],1) if not np.isnan(my_ms) else '' for i,my_ms in enumerate(t1)  ]
    t2a = [rounddowntoClosest(my_ms,dt,t2[i],None) if not np.isnan(my_ms) else '' for i,my_ms in enumerate(t2)  ]
    t3a = [rounddowntoClosest(my_ms,dt,t2[i],2) if not np.isnan(my_ms) else '' for i,my_ms in enumerate(t3)  ]
    
    
    
    roundedHX2=[find_nearest(vals2, h) for h in vv]

    fig, ax = plt.subplots(figsize = (10,7))
    
    hex_array = []
    cn=-1
    for xs,ys in offsets2:
        cn=cn+1
        hex_x = np.add(hex_polys[:,0],  xs)
        hex_y = np.add(hex_polys[:,1],  ys)
        if header['cellsize']>1:
                rastercoordt=utm.to_latlon(hex_x,hex_y, fuseNumber, fuseLetter,strict=0)
                hex_x = rastercoordt[ 1]
                hex_y = rastercoordt[ 0]

        ax.add_patch(Polygon(np.vstack([hex_x, hex_y]).T,
       alpha=.5,
       edgecolor="none",
      facecolor=colors2[roundedHX2[cn]]))  
                       
    from mplleaflet import mplexporter
    from mplleaflet import leaflet_renderer
    import json
    
    renderer = leaflet_renderer.LeafletRenderer(crs=None, epsg=None)
    exporter = mplexporter.Exporter(renderer)
    exporter.run(fig)
    
    gjdata = renderer.geojson()
    
    #vv3[np.isnan(vv3)]=0
    #vv3[vv3==0]=0.00001
    vv4=[str(np.round(x, 2))+' m/s' if (x>0.01 and not np.isnan(x)) else '<0.01 m/s' for x in vv3 ]
    vv5=[str(np.round(x, 2))+' m'  if not np.isnan(x) else ''  for x in vv ]
    
    def trytodoit(x,i):
        try:
            a=x[i] 
          
        except Exception as e: 
            print(e)
            a=''
        return a
    
    def tt(t2a,x): 
        if trytodoit(t2a,x)!='':
            return (datetime.datetime.strptime(trytodoit(t2a,x),"%d%b%Y %H:%M:%S")).strftime("%Y-%m-%dT%H:%M:%S")
        else: 
            return (datetime.datetime.strptime(dt[0],"%d%b%Y %H:%M:%S")).strftime("%Y-%m-%dT%H:%M:%S")
    
    [z['properties'].update({'depth1': trytodoit(vv5,i),
                             'time1':trytodoit(t2a,i),
                             's1':trytodoit(t1a,i),
                             'e1':trytodoit(t3a,i),
                             've':trytodoit(vv4,i),
                             'time':tt(t1a,i)})  for i,z in enumerate(gjdata['features']) ]
    #[trytodoit(vv4,i) for i,z in enumerate(gjdata['features'])]
    plottitle=str(dt[0])+'_to_'+str(dt[-1])
    title=re.sub(' ','',plottitle)
    title=re.sub(':','',title)
    
    timeserie=[(datetime.datetime.strptime(dt[k],"%d%b%Y %H:%M:%S")).strftime("%Y-%m-%dT%H:%M:%S") for k in range(0,len(dt))]
    emptylist = {}
    for i,z in enumerate(gjdata['features']):
                    emptylist[i]=gettime2(z,dt,i,timeserie) 
                    
    from mplleaflet import _display
    if op:
        dohtm(emptylist,gjdata,timeserie[0]+'-'+timeserie[-1],'base_timeserie4.html',working_dir+project_name+'warning.html',timeserie,len(timeserie))
        
    plt.close(fig)
    return gjdata

      